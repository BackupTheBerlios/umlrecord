<html>
<head>
<title>test</title>
<meta http-equiv="Content-type" content="text/html; charset=iso-8859-2">
</head>
<body>
<form action="test.php" method="GET">
<p><label>Host: </label><input name="hostip" value="<? echo $_GET['hostip']; ?>"></p>
<input type="submit" value="Connect" name="Connect">
</form>
<hr />
<?php

	require('registryClass.php');

	if (array_key_exists("Connect", $_GET) && array_key_exists("hostip", $_GET)) {
	
	$test = new registryClass();

	try{
	$o = $test->requestReg($_GET['hostip']);
		echo "<P />".$o;
	} catch(RegException $e) {
		$e->getMessage();
	}
	
	}
	
?>
</body>
</html>

