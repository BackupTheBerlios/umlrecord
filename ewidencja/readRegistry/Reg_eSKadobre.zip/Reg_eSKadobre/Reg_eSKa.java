import java.io.*;
import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.table.*;
import ca.beq.util.win32.registry.RegistryKey;
import ca.beq.util.win32.registry.RootKey;
import ca.beq.util.win32.registry.RegistryException;
import java.net.*;
import java.sql.*;



public class Reg_eSKa extends JFrame implements ActionListener {
	static final long serialVersionUID = 1L;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String url = "jdbc:mysql://localhost:3306/ewidencja";
	static final String username = "root"; //ip kompa = nazwa uzytk.
	static final String password = "";
	static final int port = 1099;
	String hostName;
	String hostAddress;
	ServerSocket socket;
	BufferedReader inputReader;
	PrintWriter outputWriter;
	JTextField	leftField;
	JTextField	rightField;
	JButton		readRegistryButton;
	JButton		readDbButton;
	JButton		writeDbButton;
	JPanel		topPanel;
	JPanel		bottomPanel;
	JTable		registryTable;
	JTable		DbTable;
	JLabel 		copyRight;
	ImageIcon 	theIcon = new ImageIcon("piorunS.gif");
	Image 		theImage = theIcon.getImage();
	Font 		copyRightFont = new Font("SansSerif",Font.BOLD,10);
	ActionEvent 	eventForDbTable;
	ActionEvent 	eventForRegistryTable;
	ArrayList<Object> dbNameSoftList;
	ArrayList<Object> dbIdSoftList;
	ArrayList<Object> softList;
	Object [] softListSort;
	ArrayListComparator softComperator;
		
		void readReg(){
			softList = new ArrayList<Object>();
			try{
				RegistryKey r1 = new RegistryKey(RootKey.HKEY_CURRENT_USER, "Software");
				if(r1.hasSubkeys()) {
					Iterator i = r1.subkeys();
   					while(i.hasNext()) {
      						RegistryKey x = (RegistryKey)i.next();
						char backslash = '\\';
						String product = x.toString();
						int lI = product.lastIndexOf(backslash);
						product = product.substring(lI+1,product.length());
      						if(!softList.contains(product)){
							softList.add(product);
						}
							} // while
					} // if
				RegistryKey r2 = new RegistryKey(RootKey.HKEY_LOCAL_MACHINE, "SOFTWARE");
				if(r2.hasSubkeys()) {
					Iterator i2 = r2.subkeys();
   					while(i2.hasNext()) {
      						RegistryKey x2 = (RegistryKey)i2.next();
						char backslash = '\\';
						String product = x2.toString();
						int lI2 = product.lastIndexOf(backslash);
						product = product.substring(lI2+1,product.length());
						if(!softList.contains(product)){
							softList.add(product);
						}
   							} // while
					} // if
					
			}catch( RegistryException re){JOptionPane.showMessageDialog(null,"Error","Error::readRegistry()",JOptionPane.ERROR_MESSAGE);}
			catch( IndexOutOfBoundsException ie){JOptionPane.showMessageDialog(null,"Error","Error::array:add()",JOptionPane.ERROR_MESSAGE);}
			softListSort = softList.toArray();
			Arrays.sort(softListSort,softComperator);
		}
		
		void writeDB(){
			int id_komputer_temp;
			String hostNameQ = "'" + hostName + "'";
			String hostAddressQ = "'" + hostAddress + "'";
			try {
				Class.forName(driver);
				Connection connection = DriverManager.getConnection(url, username, password);
				Statement statement = connection.createStatement();
				String query =	"SELECT id_komputer_temp FROM komputery_temp where nazwa = " + hostNameQ + " and numer_ip = " + hostAddressQ + " ;";
				ResultSet resultSet = statement.executeQuery(query);
					resultSet.next();
					id_komputer_temp = resultSet.getInt("id_komputer_temp");
				
				query = "DELETE FROM oprogramowanie_temp where id_komputer_temp = " + id_komputer_temp + " ;";
				statement.execute(query);
				
				for (int i = 0; i < softListSort.length; i++) {
					query = "INSERT INTO oprogramowanie_temp (id_komputer_temp,nazwa) VALUES ( " + id_komputer_temp + " , '" + softListSort[i].toString() + "' );";
					statement.execute(query);
				}
				
				connection.close();
			} catch(ClassNotFoundException cnfe) {JOptionPane.showMessageDialog(null,"Error","DataBase_Connection_Error..",JOptionPane.ERROR_MESSAGE);
			} catch(SQLException sqle) {System.err.println("Error with connection: " + sqle); JOptionPane.showMessageDialog(null,"Error","Error::DataBase writing.",JOptionPane.ERROR_MESSAGE);}
		}
		
		void uploadDB(){
			readReg();
			RegistryTableModel forRegistryTable = new RegistryTableModel(softListSort);
			registryTable.setModel(forRegistryTable); 		
			registryTable.doLayout();
			writeDB();
			readDB();
			DbTableModel forDbTable = new DbTableModel(dbNameSoftList, dbIdSoftList, hostName, hostAddress);
			DbTable.setModel(forDbTable); 	
			DbTable.doLayout();
		}
		
		void readDB(){
			int id_komputer_temp;
			String hostNameQ = "'" + hostName + "'";
			String hostAddressQ = "'" + hostAddress + "'";
			dbNameSoftList = new ArrayList<Object>();
			dbIdSoftList = new ArrayList<Object>();
			try {
				Class.forName(driver);
				Connection connection = DriverManager.getConnection(url, username, password);
				Statement statement = connection.createStatement();
				String query =	"SELECT id_komputer_temp FROM komputery_temp where nazwa = " + hostNameQ + " and numer_ip = " + hostAddressQ + " ;";
				try {
				ResultSet resultSet = statement.executeQuery(query);
				resultSet.next();
				resultSet.getString("id_komputer_temp");
				} catch(SQLException sqle) {
				query =	"INSERT INTO komputery_temp (nazwa,numer_ip) VALUES ( " + hostNameQ + " , " + hostAddressQ + ")";
				statement.execute(query);
				}
				query =	"SELECT id_komputer_temp FROM komputery_temp where nazwa = " + hostNameQ + " and numer_ip = " + hostAddressQ + " ;";
				ResultSet resultSet = statement.executeQuery(query);
					resultSet.next();
					id_komputer_temp = resultSet.getInt("id_komputer_temp");
				query = "SELECT * FROM oprogramowanie_temp where id_komputer_temp = " + id_komputer_temp;
				resultSet = statement.executeQuery(query);
					while(resultSet.next()) {
						dbNameSoftList.add(resultSet.getString("nazwa"));
						dbIdSoftList.add(resultSet.getString("id_oprogramowanie_temp"));
					}
				connection.close();
			} catch(ClassNotFoundException cnfe) {JOptionPane.showMessageDialog(null,"Error","DataBase_Connection_Error..",JOptionPane.ERROR_MESSAGE);
			} catch(SQLException sqle) {System.err.println("Error with connection: " + sqle); JOptionPane.showMessageDialog(null,"Error","ExecuteQuery has failed.",JOptionPane.ERROR_MESSAGE);}
		}
	
	
		public Reg_eSKa(){
			super(" readRegistry ");
			//setTitle(" readRegistry ");
			setIconImage(theImage);
			try{
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			}catch(Exception wievE){JOptionPane.showMessageDialog(null,"Error","Error::setLookAndFeel()",JOptionPane.ERROR_MESSAGE);}
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.getContentPane().setLayout(new BorderLayout());
			
			try {
			hostName = InetAddress.getLocalHost().getHostName();
			hostAddress = InetAddress.getLocalHost().getHostAddress();
			}catch(UnknownHostException ue){JOptionPane.showMessageDialog(null,"Error","Error::getLocalHost()",JOptionPane.ERROR_MESSAGE);}
			
			softComperator = new ArrayListComparator();
			
			topPanel = new JPanel();
			topPanel.setLayout(new FlowLayout());
			topPanel.add(readRegistryButton = new JButton("read Registry"));
			topPanel.add(writeDbButton = new JButton("write in Database"));
			topPanel.add(readDbButton = new JButton("read Database"));
			
			
			
			readRegistryButton.addActionListener(this);
			writeDbButton.addActionListener(this);
			readDbButton.addActionListener(this);
			
			
			bottomPanel = new JPanel();
			copyRight = new JLabel(" CopyRight::eS.Ka:: ",SwingConstants.CENTER);
			copyRight.setFont(copyRightFont);
			copyRight.setForeground(Color.gray);
			bottomPanel.setLayout(new FlowLayout());
			bottomPanel.add(copyRight,"Center");
			bottomPanel.setBorder(BorderFactory.createEtchedBorder());
			
			
			this.getContentPane().add(topPanel,BorderLayout.NORTH);
			this.getContentPane().add(bottomPanel,BorderLayout.SOUTH);
			this.getContentPane().add(new JScrollPane(registryTable = new JTable()),BorderLayout.WEST);
			this.getContentPane().add(new JScrollPane(DbTable = new JTable()),BorderLayout.EAST);
			readReg();
			readDB();
			RegistryTableModel forRegistryTable = new RegistryTableModel(softListSort);
			registryTable.setModel(forRegistryTable); 		
			registryTable.doLayout();
			registryTable.setBackground(Color.white);
			registryTable.setSelectionForeground(Color.blue.darker());
			registryTable.setSelectionBackground(Color.white.darker());
			registryTable.setShowGrid(false);
			DbTableModel forDbTable = new DbTableModel(dbNameSoftList, dbIdSoftList, hostName, hostAddress);
			DbTable.setModel(forDbTable); 	
			DbTable.doLayout();
			DbTable.setBackground(Color.white);
			DbTable.setSelectionForeground(Color.blue.darker());
			DbTable.setSelectionBackground(Color.white.darker());
			DbTable.setShowGrid(false);
			eventForDbTable = new ActionEvent(DbTable,0,"");
			eventForRegistryTable = new ActionEvent(registryTable,0,"");
			actionPerformed(eventForDbTable);
			actionPerformed(eventForRegistryTable);
			
			
			this.pack();
			this.setSize(946,600);
			this.setResizable(false);
			
			
			if (SystemTray.isSupported()) {
				SystemTray theTray = SystemTray.getSystemTray();
				Image image = Toolkit.getDefaultToolkit().getImage("piorunS.gif");
				PopupMenu popup = new PopupMenu();
				MenuItem welcome = new MenuItem(" readRegistry ");
				welcome.setEnabled(false);
				MenuItem exitItem = new MenuItem("Close");
				exitItem.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						setVisible(false); 
						System.exit(1);
					}
				});
				popup.add(welcome);
				popup.add("-");
				popup.add(exitItem);
				TrayIcon trayIcon = new TrayIcon(image, " readRegistry ", popup);
				trayIcon.addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						if (e.getClickCount() == 2){
							setVisible(false);
						} else if (e.getClickCount() == 1){
							setVisible(true);
						}
					}
				});
				try {
					theTray.add(trayIcon);
				} catch (AWTException se) {
					JOptionPane.showMessageDialog(null,"Error","Error::systemTray()",JOptionPane.ERROR_MESSAGE);	}
        
			this.setVisible(false);
			} else {
				this.setVisible(true); 
			}
			
			
			try {
				socket = new ServerSocket(port);
				Socket s;
				while ((s = socket.accept ()) != null) {
					inputReader = new BufferedReader (new InputStreamReader (s.getInputStream ()));
					outputWriter = new PrintWriter (s.getOutputStream ());
					String line = inputReader.readLine();
					uploadDB();
					outputWriter.flush ();
					outputWriter.println ("Registry has been read. DataBase has been uploaded.");
					outputWriter.flush ();
					inputReader.close ();
					outputWriter.close ();
					s.close ();
				}
			} catch (IOException ioe) {
				JOptionPane.showMessageDialog(null,"Error","Error::ServerSocket()",JOptionPane.ERROR_MESSAGE);
			} 
		}
			
			
			public void actionPerformed(ActionEvent e){
				Object resourceObject = e.getSource();
				if(e == eventForDbTable || resourceObject == readDbButton || resourceObject == writeDbButton){
					if(resourceObject == writeDbButton){
						writeDB();
						readDB();
						DbTableModel forDbTable = new DbTableModel(dbNameSoftList, dbIdSoftList, hostName, hostAddress);
						DbTable.setModel(forDbTable); 	
						DbTable.doLayout();
					}
					else {
						readDB();
						DbTableModel forDbTable = new DbTableModel(dbNameSoftList, dbIdSoftList, hostName, hostAddress);
						DbTable.setModel(forDbTable); 	
						DbTable.doLayout();
					}
				}
				else if(e == eventForRegistryTable || resourceObject == readRegistryButton){
					readReg();
					RegistryTableModel forRegistryTable = new RegistryTableModel(softListSort);
					registryTable.setModel(forRegistryTable); 		
					registryTable.doLayout();
					}
			}
			
			public static void main (String args[]){
				JFrame Test = new Reg_eSKa();
			}
}


class RegistryTableModel extends DefaultTableModel{
	static final long serialVersionUID = 1L;
	int columnCount=1;
	int rowCount;
	Object[][] data;
	String[] columnNames={"Software from Windows' Registry"};
	
	RegistryTableModel(Object [] softListSort){
		data = new Object[softListSort.length][columnCount];
		for (int i = 0; i < softListSort.length; i++) {
			data[i][0] = softListSort[i].toString(); 
		}
		setDataVector (data, columnNames);
	}
	
	public boolean isCellEditable (int row, int column)
	{
		return false;
	}
}

class DbTableModel extends DefaultTableModel{
	static final long serialVersionUID = 1L;
	int columnCount=3;
	int rowCount;
	Object[][] data;
	String[] columnNames={"HostName", "HostAddressIP", "Software from DataBase"};
	
	DbTableModel(ArrayList<Object> dbNameSoftList, ArrayList<Object> dbIdSoftList, String hostName, String hostAddress){
		data = new Object[dbNameSoftList.size()][columnCount];
		for (int i = 0; i < dbNameSoftList.size(); i++) {
			data[i][0] = hostName;
			data[i][1] = hostAddress;
			data[i][2] = dbNameSoftList.get(i).toString(); 
		}
		setDataVector (data, columnNames);
	}
	
	public boolean isCellEditable (int row, int column)
	{
		return false;
	}
}

class ArrayListComparator implements Comparator<Object>{
	static final long serialVersionUID = 1L;
	public int compare(Object o1, Object o2){
		String s1 = o1.toString();
		String s2 = o2.toString();
		return (s1.toLowerCase()).compareTo(s2.toLowerCase());
	}
							
	public boolean equals (Object obj){
		 return false; }
}


	
