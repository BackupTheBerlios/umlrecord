<?php

class RegException extends Exception{}
	
class registryClass {
	var $service_port = 1099;
	var $out;
	var $in = "uploadDB() \n";
	
	public function requestReg($addressIp){
		
		$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		
		if ($socket === false) {
			throw new RegException("socket_create() failed: " . socket_strerror(socket_last_error()));
			return false;
		}

		flush ();
		$result = socket_connect($socket, $addressIp, $this->service_port); 
		if ($result === false) {
			throw new RegException("socket_connect() failed: " . socket_strerror(socket_last_error($socket))); 
			return false;
		}

		flush ();
		socket_write($socket, $this->in, strlen($this->in)); 

		flush ();
		while ($this->out = socket_read($socket, 2048)) {
		return	$this->out;
		flush ();
		}
		
		socket_close($socket);
	}
	

}

?>


